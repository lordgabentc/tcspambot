Since falcon decided to be a butt hurt faggot and leak my bot here everyone the offical release of alphabot.
There are a couple of commands you can use while the bot is flooding.
Enjoy fucking over tinychat!!!
message NEWFLOODMESSAGEHERE
password ROOMPASSWORDIFTHEYPUTONEON
room NEWROOMNAME
~ ZiN